/*
 * TEALsim - MIT TEAL Project
 * Copyright (c) 2004 The Massachusetts Institute of Technology. All rights reserved.
 * Please see license.txt in top level directory for full license.
 * 
 * http://icampus.mit.edu/teal/TEALsim
 * 
 * $Id: TextField.java,v 1.3 2007/07/16 22:05:12 pbailey Exp $ 
 * 
 */

package teal.ui.control;


/**
 * @author mckinney
 *
 */
public class TextField extends AbstractPropertyItem {

    /**
     * 
     */
    public TextField() {
        super();
        // TODO Auto-generated constructor stub
    }

    /* (non-Javadoc)
     * @see teal.ui.control.AbstractPropertyItem#setValue(java.lang.Object)
     */
    public void setValue(Object obj) {
        // TODO Auto-generated method stub

    }

    /* (non-Javadoc)
     * @see teal.ui.control.AbstractPropertyItem#getValue()
     */
    public Object getValue() {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see teal.ui.control.AbstractPropertyItem#getControlVisible()
     */
    public boolean getControlVisible() {
        // TODO Auto-generated method stub
        return false;
    }

    /* (non-Javadoc)
     * @see teal.ui.control.AbstractPropertyItem#setControlVisible(boolean)
     */
    public void setControlVisible(boolean b) {
        // TODO Auto-generated method stub

    }

}
